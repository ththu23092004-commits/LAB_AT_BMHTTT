
package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_Menu extends JFrame {

    public frm_Menu() {

        setTitle("LAB 1 - Mã hóa đối xứng cổ điển");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setSize(700, 650);

        setLocationRelativeTo(null);

        setResizable(false);

        initComponents();
    }

    private void initComponents() {

        JPanel main = new JPanel();

        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));

        main.setBackground(new Color(245, 247, 250));

        main.setBorder(
            BorderFactory.createEmptyBorder(25, 30, 25, 30)
        );

        JLabel title = new JLabel(
            "LAB 1 - MÃ HÓA ĐỐI XỨNG CỔ ĐIỂN"
        );

        title.setFont(
            new Font("Segoe UI", Font.BOLD, 22)
        );

        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel(
            "Chọn một bài để mở form tương ứng:"
        );

        subtitle.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        main.add(title);

        main.add(Box.createVerticalStrut(12));

        main.add(subtitle);

        main.add(Box.createVerticalStrut(25));

        addMenuButton(main, "1.1 Caesar",
            () -> new frm_Caesar().setVisible(true));

        addMenuButton(main, "1.2 Vigenère",
            () -> new frm_Vigenere().setVisible(true));

        addMenuButton(main, "1.3 Rail Fence",
            () -> new frm_RailFence().setVisible(true));

        addMenuButton(main, "1.4 Playfair",
            () -> new frm_Playfair().setVisible(true));

        addMenuButton(main, "1.5 Transposition",
            () -> new frm_Transposition().setVisible(true));

        addMenuButton(main, "1.6 Autokey",
            () -> new frm_Autokey().setVisible(true));

        addMenuButton(main, "Nâng cao 01 - Tổng hợp",
            () -> new frm_TongHop().setVisible(true));

addMenuButton(main, "Nâng cao 02 - Tấn công",
    () -> new frm_TanCong().setVisible(true));

        addMenuButton(main, "Kết nối SQL Server",
            () -> new frm_KetNoiSQL().setVisible(true));

        main.add(Box.createVerticalStrut(18));

        JLabel footer = new JLabel(
            "Mỗi form mở ra là một cửa sổ riêng; đóng form con không làm tắt chương trình."
        );

        footer.setFont(
            new Font("Segoe UI", Font.ITALIC, 11)
        );

        footer.setAlignmentX(Component.CENTER_ALIGNMENT);

        main.add(footer);

        add(main);
    }

    private void addMenuButton(
        JPanel panel,
        String text,
        Runnable action
    ) {

        JButton button = new JButton(text);

        button.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        button.setPreferredSize(
            new Dimension(350, 36)
        );

        button.setMaximumSize(
            new Dimension(350, 36)
        );

        button.setAlignmentX(Component.CENTER_ALIGNMENT);

        button.addActionListener(e -> action.run());

        panel.add(button);

        panel.add(Box.createVerticalStrut(9));
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new frm_Menu().setVisible(true);

        });
    }
}
