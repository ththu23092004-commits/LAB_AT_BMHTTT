
package week_01;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class frm_LichSu extends JFrame {

    private JTable tbl_history;
    private JButton btn_refresh;
    private JLabel lbl_status;

    public frm_LichSu() {

        setTitle("Lịch sử thao tác (SQL Server)");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 430);
        setLocationRelativeTo(null);

        initComponents();

        tbl_history.setModel(HistoryDao.emptyModel());

        loadData();
    }

    private void initComponents() {

        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        JLabel title = new JLabel(
            "LỊCH SỬ THAO TÁC - BẢNG DBO.HISTORY",
            SwingConstants.CENTER
        );

        title.setFont(
            new Font("Segoe UI", Font.BOLD, 19)
        );

        main.add(title, BorderLayout.NORTH);

        tbl_history = new JTable();
        tbl_history.setRowHeight(25);
        tbl_history.setAutoResizeMode(
            JTable.AUTO_RESIZE_OFF
        );

        JScrollPane scroll = new JScrollPane(tbl_history);

        main.add(scroll, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());

        btn_refresh = new JButton("Tải lại");

        lbl_status = new JLabel("Đang tải...");

        bottom.add(btn_refresh, BorderLayout.WEST);
        bottom.add(lbl_status, BorderLayout.CENTER);

        main.add(bottom, BorderLayout.SOUTH);

        add(main);

        btn_refresh.addActionListener(e -> loadData());
    }

    private void loadData() {

        try {

            DefaultTableModel model =
                HistoryDao.loadLatest(50);

            tbl_history.setModel(model);

            tbl_history.setAutoResizeMode(
                JTable.AUTO_RESIZE_OFF
            );

            int[] widths = {60, 160, 120, 100, 300, 300};

            for (int i = 0; i < widths.length; i++) {
                tbl_history.getColumnModel()
                    .getColumn(i)
                    .setPreferredWidth(widths[i]);
            }

            lbl_status.setText(
                "Đã tải " + tbl_history.getRowCount()
                + " dòng mới nhất từ dbo.history."
            );

        } catch (SQLException ex) {

            lbl_status.setText(
                "Không đọc được lịch sử: " + ex.getMessage()
            );

        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new frm_LichSu().setVisible(true);
        });
    }
}
