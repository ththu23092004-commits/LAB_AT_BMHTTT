
package week_01;

/**
 * Hoan vi cot theo khoa liet ke thu tu doc cac cot.
 * Vi du: 2,3,1.
 */
public final class TranspositionCipher {

    private TranspositionCipher() {
    }

    public static String encrypt(String text, int[] key) {
        return process(text, key, true);
    }

    public static String decrypt(String text, int[] key) {
        return process(text, key, false);
    }

    /**
     * Chuyen chuoi khoa "2,3,1" thanh mang {2, 3, 1}.
     */
    public static int[] parseKey(String keyText) {

        if (keyText == null || keyText.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Vui long nhap khoa, vi du 2,3,1."
            );
        }

        String[] parts = keyText.trim().split("\\s*,\\s*");

        int[] key = new int[parts.length];

        try {

            for (int i = 0; i < parts.length; i++) {
                key[i] = Integer.parseInt(parts[i]);
            }

        } catch (NumberFormatException ex) {

            throw new IllegalArgumentException(
                "Khoa phai la cac so cach nhau boi dau phay, vi du 2,3,1."
            );
        }

        validateKey(key);

        return key;
    }

    private static void validateKey(int[] key) {

        if (key == null || key.length < 2 || key.length > 50) {

            throw new IllegalArgumentException(
                "Khoa phai co tu 2 den 50 cot."
            );
        }

        boolean[] used = new boolean[key.length + 1];

        for (int col : key) {

            if (col < 1 || col > key.length || used[col]) {

                throw new IllegalArgumentException(
                    "Khoa phai la hoan vi 1..m."
                );
            }

            used[col] = true;
        }
    }

    private static String process(
            String text,
            int[] key,
            boolean encrypt) {

        if (text == null) {
            throw new IllegalArgumentException(
                "Van ban khong duoc de null."
            );
        }

        validateKey(key);

        int[] chars = text.codePoints().toArray();

        int length = chars.length;

        int columns = key.length;

        int rows = (length + columns - 1) / columns;

        int[][] grid = new int[rows][columns];

        int offset = 0;

        if (encrypt) {

            // Dien van ban theo tung hang.

            for (int i = 0; i < length; i++) {

                grid[i / columns][i % columns] = chars[i];
            }

            int[] result = new int[length];

            // Doc cac cot theo thu tu khoa.

            for (int column : key) {

                for (int row = 0; row < rows; row++) {

                    if (row * columns + column - 1 < length) {

                        result[offset++] =
                            grid[row][column - 1];
                    }
                }
            }

            return new String(result, 0, result.length);
        }

        // Giai ma: dien nguoc lai theo tung cot.

        for (int column : key) {

            for (int row = 0; row < rows; row++) {

                if (row * columns + column - 1 < length) {

                    grid[row][column - 1] = chars[offset++];
                }
            }
        }

        // Doc lai theo tung hang.

        int[] result = new int[length];

        for (int i = 0; i < length; i++) {

            result[i] = grid[i / columns][i % columns];
        }

        return new String(result, 0, result.length);
    }
}
