
package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_KetNoiSQL extends JFrame {

    private JTextField txt_server;
    private JTextField txt_port;
    private JTextField txt_database;
    private JTextField txt_user;
    private JPasswordField txt_password;

    private JButton btn_test;
    private JButton btn_history;

    private JLabel lbl_status;

    public frm_KetNoiSQL() {

        setTitle("Kết nối Microsoft SQL Server");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(620, 390);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {

        JPanel main = new JPanel(new GridBagLayout());
        main.setBackground(new Color(245, 247, 250));
        main.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 8, 7, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel(
            "KẾT NỐI MICROSOFT SQL SERVER",
            SwingConstants.CENTER
        );

        title.setFont(new Font("Segoe UI", Font.BOLD, 20));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        main.add(title, gbc);

        gbc.gridwidth = 1;

        txt_server = new JTextField("127.0.0.1");
        txt_port = new JTextField("1433");
        txt_database = new JTextField("LAB1_MaHoaCoDien");
        txt_user = new JTextField("lab1_user");
        txt_password = new JPasswordField();

        addField(main, gbc, 1, "Server:", txt_server);
        addField(main, gbc, 2, "Port:", txt_port);
        addField(main, gbc, 3, "Database:", txt_database);
        addField(main, gbc, 4, "User:", txt_user);
        addField(main, gbc, 5, "Password:", txt_password);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        buttons.setBackground(new Color(245, 247, 250));

        btn_test = new JButton("Test Connection");
        btn_history = new JButton("Xem lịch sử");

        buttons.add(btn_test);
        buttons.add(btn_history);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;

        main.add(buttons, gbc);

        lbl_status = new JLabel("Chưa kết nối.");
        lbl_status.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;

        main.add(lbl_status, gbc);

        add(main);

        btn_test.addActionListener(e -> testConnection());

        btn_history.addActionListener(e -> {
            new frm_LichSu().setVisible(true);
        });
    }

    private void addField(
        JPanel panel,
        GridBagConstraints gbc,
        int row,
        String label,
        JTextField field
    ) {

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;

        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        panel.add(lbl, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1;

        field.setPreferredSize(new Dimension(350, 28));

        panel.add(field, gbc);
    }

    private void testConnection() {

        try {

            int port = Integer.parseInt(
                txt_port.getText().trim()
            );

            DbConfig.set(
                txt_server.getText().trim(),
                port,
                txt_database.getText().trim(),
                txt_user.getText().trim(),
                txt_password.getPassword()
            );

            String result = DbConfig.test();

            lbl_status.setText(
                "<html><font color='green'>" +
                result +
                "</font></html>"
            );

            JOptionPane.showMessageDialog(
                this,
                result,
                "Kết nối thành công",
                JOptionPane.INFORMATION_MESSAGE
            );

        } catch (Exception ex) {

            DbConfig.clear();

            lbl_status.setText(
                "<html><font color='red'>Kết nối thất bại: " +
                ex.getMessage() +
                "</font></html>"
            );

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Không kết nối được SQL Server",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            new frm_KetNoiSQL().setVisible(true);
        });
    }
}
