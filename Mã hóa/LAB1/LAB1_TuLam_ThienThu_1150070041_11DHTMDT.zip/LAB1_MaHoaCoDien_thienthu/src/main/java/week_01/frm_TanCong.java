
package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_TanCong extends JFrame {

    private JTextArea txt_cipher;
    private JTextField txt_known_plain;
    private JTextField txt_known_cipher;
    private JTextArea txt_result;
    private JLabel lbl_status;

    private JButton btn_bruteforce;
    private JButton btn_frequency;
    private JButton btn_known;

    public frm_TanCong() {

        setTitle("Phân tích mật mã cổ điển");

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setSize(700, 620);

        setLocationRelativeTo(null);

        setResizable(false);

        initComponents();
    }

    private void initComponents() {

        JPanel main = new JPanel();

        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));

        main.setBackground(new Color(245, 247, 250));

        main.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel title = new JLabel(
            "PHÂN TÍCH (TẤN CÔNG) MẬT MÃ CỔ ĐIỂN"
        );

        title.setFont(
            new Font("Segoe UI", Font.BOLD, 19)
        );

        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        main.add(title);

        main.add(Box.createVerticalStrut(15));

        // CIPHERTEXT

        JLabel lbl_cipher = new JLabel("Ciphertext:");

        lbl_cipher.setAlignmentX(Component.LEFT_ALIGNMENT);

        txt_cipher = new JTextArea(2, 55);

        txt_cipher.setLineWrap(true);

        txt_cipher.setWrapStyleWord(true);

        txt_cipher.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        JScrollPane scrollCipher = new JScrollPane(txt_cipher);

        scrollCipher.setPreferredSize(
            new Dimension(620, 65)
        );

        scrollCipher.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 65)
        );

        scrollCipher.setAlignmentX(Component.LEFT_ALIGNMENT);

        main.add(lbl_cipher);

        main.add(scrollCipher);

        main.add(Box.createVerticalStrut(12));

        // BUTTONS

        JPanel attackPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 8, 5)
        );

        attackPanel.setBackground(new Color(245, 247, 250));

        attackPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        btn_bruteforce = new JButton("Brute Force Caesar");

        btn_frequency = new JButton("Frequency Analysis");

        attackPanel.add(btn_bruteforce);

        attackPanel.add(btn_frequency);

        main.add(attackPanel);

        main.add(Box.createVerticalStrut(12));

        // KNOWN PLAINTEXT

        JPanel knownPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 8, 5)
        );

        knownPanel.setBackground(new Color(245, 247, 250));

        knownPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lbl_plain = new JLabel("Bản rõ đã biết:");

        txt_known_plain = new JTextField("HELLO", 12);

        JLabel lbl_known_cipher = new JLabel("Bản mã:");

        txt_known_cipher = new JTextField("RIJVS", 12);

        knownPanel.add(lbl_plain);

        knownPanel.add(txt_known_plain);

        knownPanel.add(lbl_known_cipher);

        knownPanel.add(txt_known_cipher);

        main.add(knownPanel);

        main.add(Box.createVerticalStrut(5));

        btn_known = new JButton(
            "Known Plaintext (Vigenere)"
        );

        btn_known.setAlignmentX(Component.LEFT_ALIGNMENT);

        main.add(btn_known);

        main.add(Box.createVerticalStrut(15));

        // RESULT

        JLabel lbl_result = new JLabel("Kết quả:");

        lbl_result.setAlignmentX(Component.LEFT_ALIGNMENT);

        txt_result = new JTextArea(12, 55);

        txt_result.setLineWrap(false);

        txt_result.setEditable(false);

        txt_result.setFont(
            new Font("Consolas", Font.PLAIN, 13)
        );

        JScrollPane scrollResult = new JScrollPane(txt_result);

        scrollResult.setPreferredSize(
            new Dimension(620, 260)
        );

        scrollResult.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 260)
        );

        scrollResult.setAlignmentX(Component.LEFT_ALIGNMENT);

        main.add(lbl_result);

        main.add(scrollResult);

        main.add(Box.createVerticalStrut(12));

        // STATUS

        lbl_status = new JLabel("Sẵn sàng.");

        lbl_status.setAlignmentX(Component.LEFT_ALIGNMENT);

        main.add(lbl_status);

        add(main);

        // EVENTS

        btn_bruteforce.addActionListener(e -> bruteForce());

        btn_frequency.addActionListener(e -> frequency());

        btn_known.addActionListener(e -> knownPlaintext());
    }

    // BRUTE FORCE

    private void bruteForce() {

        String cipher = txt_cipher.getText().trim();

        if (cipher.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Ciphertext."
            );

            return;
        }

        try {

            txt_result.setText(
                AttackDemos.caesarBruteForce(cipher)
            );

            txt_result.setCaretPosition(0);

            lbl_status.setText(
                "Đã thử đủ 26 khóa Caesar."
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Lỗi",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // FREQUENCY ANALYSIS

    private void frequency() {

        String cipher = txt_cipher.getText().trim();

        if (cipher.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Ciphertext."
            );

            return;
        }

        try {

            txt_result.setText(
                AttackDemos.frequency(cipher)
            );

            txt_result.setCaretPosition(0);

            lbl_status.setText(
                "Đã thống kê tần suất chữ cái."
            );

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Lỗi",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // KNOWN PLAINTEXT

    private void knownPlaintext() {

        try {

            String key = AttackDemos.knownPlaintext(
                txt_known_plain.getText(),
                txt_known_cipher.getText()
            );

            txt_result.setText(
                "Khóa Vigenère suy ra từng vị trí: "
                + key
                + "\nNếu khóa ngắn hơn bản rõ, khóa sẽ lặp lại."
            );

            lbl_status.setText(
                "Khóa suy ra: " + key
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new frm_TanCong().setVisible(true);

        });
    }
}
