
package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_Playfair extends JFrame {

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;
    private JTextArea txt_matrix;

    private JTextField txt_key;

    private JLabel lbl_status;

    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JButton btn_matrix;

    public frm_Playfair() {

        setTitle("Playfair Cipher");

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setSize(850, 680);

        setLocationRelativeTo(null);

        setMinimumSize(new Dimension(760, 620));

        initComponents();
    }

    private void initComponents() {

        JPanel mainPanel = new JPanel(new GridBagLayout());

        mainPanel.setBackground(new Color(245, 247, 250));

        mainPanel.setBorder(
            BorderFactory.createEmptyBorder(15, 20, 15, 20)
        );

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(5, 7, 5, 7);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;

        JLabel lbl_title = new JLabel(
            "MẬT MÃ PLAYFAIR",
            SwingConstants.CENTER
        );

        lbl_title.setFont(
            new Font("Segoe UI", Font.BOLD, 24)
        );

        JLabel lbl_plaintext = new JLabel("Plaintext:");

        JLabel lbl_key = new JLabel("Key:");

        JLabel lbl_keyHint = new JLabel(
            "Chỉ gồm chữ A-Z, ví dụ KEYWORD"
        );

        JLabel lbl_matrixTitle = new JLabel("Key Matrix:");

        JLabel lbl_ciphertext = new JLabel("Ciphertext:");

        txt_plaintext = new JTextArea(3, 50);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        txt_ciphertext = new JTextArea(3, 50);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        txt_key = new JTextField("KEYWORD", 15);
        txt_key.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        txt_matrix = new JTextArea(5, 9);
        txt_matrix.setEditable(false);
        txt_matrix.setLineWrap(false);
        txt_matrix.setFont(
            new Font("Monospaced", Font.BOLD, 14)
        );

        txt_matrix.setBackground(Color.WHITE);

        lbl_status = new JLabel("Sẵn sàng.");

        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open Ciphertext File");
        btn_save = new JButton("Save Ciphertext File");
        btn_matrix = new JButton("Generate Key Matrix");

        btn_encrypt.addActionListener(e -> encrypt());

        btn_decrypt.addActionListener(e -> decrypt());

        btn_open.addActionListener(e -> openFile());

        btn_save.addActionListener(e -> saveFile());

        btn_matrix.addActionListener(e -> generateMatrix());

        // TITLE

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;

        mainPanel.add(lbl_title, gbc);

        // PLAINTEXT

        gbc.gridy = 1;

        mainPanel.add(lbl_plaintext, gbc);

        gbc.gridy = 2;

        gbc.fill = GridBagConstraints.BOTH;

        mainPanel.add(
            new JScrollPane(txt_plaintext),
            gbc
        );

        // KEY

        gbc.gridy = 3;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;

        mainPanel.add(lbl_key, gbc);

        gbc.gridx = 1;

        mainPanel.add(txt_key, gbc);

        gbc.gridx = 2;

        mainPanel.add(lbl_keyHint, gbc);

        // MATRIX

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;

        mainPanel.add(lbl_matrixTitle, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.BOTH;

        mainPanel.add(
            new JScrollPane(txt_matrix),
            gbc
        );

        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        mainPanel.add(btn_matrix, gbc);

        // CIPHERTEXT

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        mainPanel.add(lbl_ciphertext, gbc);

        gbc.gridy = 7;
        gbc.fill = GridBagConstraints.BOTH;

        mainPanel.add(
            new JScrollPane(txt_ciphertext),
            gbc
        );

        // BUTTONS

        JPanel buttonPanel = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 8, 5)
        );

        buttonPanel.setBackground(
            new Color(245, 247, 250)
        );

        buttonPanel.add(btn_encrypt);
        buttonPanel.add(btn_decrypt);
        buttonPanel.add(btn_open);
        buttonPanel.add(btn_save);

        gbc.gridy = 8;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        mainPanel.add(buttonPanel, gbc);

        // STATUS

        gbc.gridy = 9;

        mainPanel.add(lbl_status, gbc);

        add(mainPanel);
    }

    // ENCRYPT

    private void encrypt() {

        String plaintext = txt_plaintext.getText();

        if (plaintext.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Plaintext trước khi mã hóa."
            );

            return;
        }

        try {

            String key = txt_key.getText().trim();

            txt_ciphertext.setText(
                PlayfairCipher.encrypt(plaintext, key)
            );

            lbl_status.setText(
                "Đã mã hóa Playfair (bỏ dấu cách, J -> I, chèn X)."
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // DECRYPT

    private void decrypt() {

        String ciphertext = txt_ciphertext.getText();

        if (ciphertext.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Hãy nhập Ciphertext trước khi giải mã."
            );

            return;
        }

        try {

            String key = txt_key.getText().trim();

            txt_plaintext.setText(
                PlayfairCipher.decrypt(ciphertext, key)
            );

            lbl_status.setText(
                "Đã giải mã Playfair (còn ký tự đệm X)."
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // OPEN FILE

    private void openFile() {

        String path = FileTextIO.openText(
            this,
            txt_ciphertext
        );

        if (path != null) {

            lbl_status.setText(
                "Đã mở tệp: " + path
            );
        }
    }

    // SAVE FILE

    private void saveFile() {

        String path = FileTextIO.saveText(
            this,
            txt_ciphertext,
            "playfair_ciphertext.txt"
        );

        if (path != null) {

            lbl_status.setText(
                "Đã lưu tệp: " + path
            );
        }
    }

    // GENERATE KEY MATRIX

    private void generateMatrix() {

        try {

            txt_matrix.setText(
                PlayfairCipher.getKeyMatrix(
                    txt_key.getText()
                )
            );

            txt_matrix.setCaretPosition(0);

            lbl_status.setText(
                "Đã tạo ma trận khóa 5x5 (I và J dùng chung ô)."
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Khóa không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new frm_Playfair().setVisible(true);

        });
    }
}
