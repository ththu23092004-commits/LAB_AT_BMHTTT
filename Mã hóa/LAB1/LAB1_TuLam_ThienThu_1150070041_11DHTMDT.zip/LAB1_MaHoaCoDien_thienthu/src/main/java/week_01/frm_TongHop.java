
package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_TongHop extends JFrame {

    private JComboBox<String> cbo_algorithm;

    private JLabel lbl_hint;
    private JLabel lbl_status;

    private JTextArea txt_plaintext;
    private JTextArea txt_ciphertext;

    private JTextField txt_key;

    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JButton btn_sql;
    private JButton btn_history;

    public frm_TongHop() {

        setTitle("Chương trình tổng hợp - 6 thuật toán");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(780, 650);
        setLocationRelativeTo(null);
        setResizable(false);

        initComponents();
    }

    private void initComponents() {

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(new Color(245, 247, 250));
        mainPanel.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel lbl_title = new JLabel(
            "CHƯƠNG TRÌNH TỔNG HỢP 6 THUẬT TOÁN CỔ ĐIỂN"
        );

        lbl_title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lbl_title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel algorithmPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 10, 5)
        );

        algorithmPanel.setBackground(new Color(245, 247, 250));
        algorithmPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lbl_algorithm = new JLabel("Thuật toán:");

        cbo_algorithm = new JComboBox<>(
            CipherTongHop.ALGORITHMS
        );

        cbo_algorithm.setPreferredSize(new Dimension(200, 30));

        lbl_hint = new JLabel("Khóa mẫu: 3");

        algorithmPanel.add(lbl_algorithm);
        algorithmPanel.add(cbo_algorithm);
        algorithmPanel.add(lbl_hint);

        JLabel lbl_plaintext = new JLabel("Plaintext:");

        txt_plaintext = new JTextArea(4, 55);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        JScrollPane scrollPlaintext = new JScrollPane(txt_plaintext);
        scrollPlaintext.setPreferredSize(new Dimension(570, 85));
        scrollPlaintext.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 85)
        );

        JPanel keyPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 10, 5)
        );

        keyPanel.setBackground(new Color(245, 247, 250));
        keyPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lbl_key = new JLabel("Key:");

        txt_key = new JTextField("3", 22);

        keyPanel.add(lbl_key);
        keyPanel.add(txt_key);

        JLabel lbl_ciphertext = new JLabel("Ciphertext:");

        txt_ciphertext = new JTextArea(4, 55);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setFont(
            new Font("Segoe UI", Font.PLAIN, 14)
        );

        JScrollPane scrollCiphertext = new JScrollPane(txt_ciphertext);
        scrollCiphertext.setPreferredSize(new Dimension(570, 85));
        scrollCiphertext.setMaximumSize(
            new Dimension(Integer.MAX_VALUE, 85)
        );

        JPanel buttonPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 8, 8)
        );

        buttonPanel.setBackground(new Color(245, 247, 250));
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open File");
        btn_save = new JButton("Save File");
        btn_sql = new JButton("Kết nối SQL Server");
        btn_history = new JButton("Xem lịch sử");

        buttonPanel.add(btn_encrypt);
        buttonPanel.add(btn_decrypt);
        buttonPanel.add(btn_open);
        buttonPanel.add(btn_save);
        buttonPanel.add(btn_sql);
        buttonPanel.add(btn_history);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setAlignmentX(Component.LEFT_ALIGNMENT);

        mainPanel.add(lbl_title);
        mainPanel.add(Box.createVerticalStrut(18));
        mainPanel.add(algorithmPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(lbl_plaintext);
        mainPanel.add(scrollPlaintext);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(keyPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(lbl_ciphertext);
        mainPanel.add(scrollCiphertext);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(buttonPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(lbl_status);

        add(mainPanel);

        // CHỌN THUẬT TOÁN

        cbo_algorithm.addActionListener(e -> {

            String algorithm =
                (String) cbo_algorithm.getSelectedItem();

            String sampleKey =
                CipherTongHop.sampleKey(algorithm);

            txt_key.setText(sampleKey);

            lbl_hint.setText("Khóa mẫu: " + sampleKey);
        });

        // ENCRYPT

        btn_encrypt.addActionListener(e -> encrypt());

        // DECRYPT

        btn_decrypt.addActionListener(e -> decrypt());

        // OPEN FILE

        btn_open.addActionListener(e -> openFile());

        // SAVE FILE

        btn_save.addActionListener(e -> saveFile());

        // KẾT NỐI SQL SERVER

        btn_sql.addActionListener(e -> {

            new frm_KetNoiSQL().setVisible(true);

        });

        // XEM LỊCH SỬ

        btn_history.addActionListener(e -> {

            if (!DbConfig.isReady()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Vui lòng kết nối SQL Server trước!",
                    "Chưa kết nối",
                    JOptionPane.WARNING_MESSAGE
                );

                return;
            }

            new frm_LichSu().setVisible(true);

        });
    }

    // ENCRYPT

    private void encrypt() {

        String algorithm =
            (String) cbo_algorithm.getSelectedItem();

        String input = txt_plaintext.getText();

        try {

            String result = CipherTongHop.encrypt(
                algorithm,
                input,
                txt_key.getText()
            );

            txt_ciphertext.setText(result);

            String saved = HistoryDao.tryInsert(
                algorithm,
                "ENCRYPT",
                input,
                result
            );

            lbl_status.setText(
                "Đã mã hóa " + algorithm + ". " + saved
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // DECRYPT

    private void decrypt() {

        String algorithm =
            (String) cbo_algorithm.getSelectedItem();

        String input = txt_ciphertext.getText();

        try {

            String result = CipherTongHop.decrypt(
                algorithm,
                input,
                txt_key.getText()
            );

            txt_plaintext.setText(result);

            String saved = HistoryDao.tryInsert(
                algorithm,
                "DECRYPT",
                input,
                result
            );

            lbl_status.setText(
                "Đã giải mã " + algorithm + ". " + saved
            );

        } catch (IllegalArgumentException ex) {

            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "Dữ liệu không hợp lệ",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // OPEN FILE

    private void openFile() {

        String path = FileTextIO.openText(
            this,
            txt_ciphertext
        );

        if (path != null) {

            lbl_status.setText(
                "Đã mở tệp: " + path
            );
        }
    }

    // SAVE FILE

    private void saveFile() {

        String path = FileTextIO.saveText(
            this,
            txt_ciphertext,
            "ciphertext.txt"
        );

        if (path != null) {

            lbl_status.setText(
                "Đã lưu tệp: " + path
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new frm_TongHop().setVisible(true);

        });
    }
}
